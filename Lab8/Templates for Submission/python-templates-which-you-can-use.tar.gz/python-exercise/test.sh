#!/bin/bash
if [ $# -ne 1 ]; then
    echo "Usage: ./test.sh <question-number>"
    exit
fi

if [ $1 -eq 1 ]; then
    python3 ./fibindex.py 13 > temp.out
    diff -Z -B ./temp.out ./output/fib1 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 1 failed, input 13"
        echo "Expected output: output/fib1"
        echo ""
    fi
    python3 ./fibindex.py 20 > temp.out
    diff -Z -B ./temp.out ./output/fib2 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 2 failed, input 20"
        echo "Expected output: output/fib2"
        echo ""
    fi
fi



if [ $1 -eq 2 ]; then
    python3 ./transpose.py ./input/trans1 > temp.out
    diff -Z -B ./temp.out ./output/trans1 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 1 failed, input: input/trans1"
        echo "Expected output: output/trans1"
        echo ""
    fi
    python3 ./transpose.py ./input/trans2 > temp.out
    diff -Z -B ./temp.out ./output/trans2 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 2 failed, input: input/trans2"
        echo "Expected output: output/trans2"
        echo ""
    fi
fi




if [ $1 -eq 3 ]; then
    python3 ./matmult.py ./input/matmult11 ./input/matmult12 temp.out
    diff -Z -B ./temp.out ./output/matmult1 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 1 failed, inputs: input/matmult11, input/matmult12"
        echo "Expected output: output/matmult1"
        echo ""
    fi
    python3 ./matmult.py ./input/matmult21 ./input/matmult22 temp.out
    diff -Z -B ./temp.out ./output/matmult2 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 2 failed, inputs: input/matmult21, input/matmult22"
        echo "Expected output: output/matmult2"
        echo ""
    fi
fi



if [ $1 -eq 4 ]; then
    python3 ./binsearch.py ./input/binsearch1 6 > temp.out
    diff -Z -B ./temp.out ./output/binsearch1 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 1 failed, inputs: input/binsearch1, 6"
        echo "Expected output: output/binsearch1"
        echo ""
    fi
    python3 ./binsearch.py ./input/binsearch2 52 > temp.out
    diff -Z -B ./temp.out ./output/binsearch2 >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Testcase 2 failed, inputs: input/binsearch2, 52"
        echo "Expected output: output/binsearch2"
        echo ""
    fi
fi
